# PriceTracker
Create a web scraping bot using Beautiful Soup to monitor and track the prices of products on Amazon.
