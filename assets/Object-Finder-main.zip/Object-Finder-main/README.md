# Object-Finder
Machine Learning &amp; Computer Vision Image Identifier - iOS App  

This app allows the user to point their phone at an object in their surroundings and have it identified through the use of a trained machine learning model

